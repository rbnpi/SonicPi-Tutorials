         README for Purcell Funeral Music for Queen Mary
This Sonic-Pi 2 program was created by Robin Newman
in September 2014.
To use it, you need either a Raspberry Pi computer with Sonic Pi version 2.0.1 or later
installed, or an Apple Computer running OSX
Installation details ore at http://sonic-pi.net/get-v2.0

The program requires an audio sample file d1.wav which is included with this download
in the folder named samples
If running on a Pi I suggest you place this in your home folder, which will be at
/home/pi/samples if you use the default logon name pi.
Choose a suitable location on the Mac: you will need to ascertain the absolute pathname
to put into the program. I placed the samples file on my Desktop. My logon name was rbm
and the absolute path was /users/rbn/Desktop/samples

Make sure that the d1.wav file is in your samples folder.

If you open the program file PurcellFuneralMusic.txt with a text editor,
leafpad on a Pi or textedit on a Mac, then you can select all the text and copy and paste
it into an empty workspace in Sonic Pi.
Make sure that the relevant lines are set up at the start of the program:
1 set_ahead_sched_time! to 4 on the Pi or 0.25 on the Mac
2 The correct line for use_sample_pack is selected and adjusted if necessary for
the location of your samples folder
3 If using a Pi, then open the Prefs tab and deselect the Print output option.
This makes the program perform better.

If you have any queries or feedback I can be reached at

robin dot newman at gmail dot com

Enjoy!